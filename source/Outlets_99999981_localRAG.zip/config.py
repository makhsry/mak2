import os
import re
import sys
import argparse

# -- Current Settings --
OLLAMA_MODEL    = "gemma4:latest"
EMBEDDING_MODEL = "nomic-embed-text"
CHROMA_DB_PATH  = "./databases/"
CHUNK_SIZE      = 500
CHUNK_OVERLAP   = 50
TOP_K_RESULTS   = 5
FOLDERS_FILE    = "folders.txt"
PROMPT_FILE     = "prompt.txt"

def _win_to_wsl(path: str) -> str:
    path = path.strip()
    m = re.match(r'^([A-Za-z]):[/\\\\](.*)', path)
    if m:
        drive, rest = m.groups()
        rest = rest.replace('\\', '/')
        return f"/mnt/{drive.lower()}/{rest}"
    return path.replace('\\', '/')

def load_folders(filepath: str = FOLDERS_FILE) -> list[str]:
    if not os.path.exists(filepath):
        return []
    folders = []
    with open(filepath, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            unix_path = _win_to_wsl(line)
            folders.append(unix_path)
    return folders

def load_prompt(filepath: str = PROMPT_FILE) -> str:
    if not os.path.exists(filepath):
        return "No prompt found."
    with open(filepath, encoding="utf-8") as fh:
        return fh.read().strip()

# -- Help and Verification Feature --
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Configuration Verifier",
        epilog="This file contains the core settings for your RAG pipeline."
    )
    parser.parse_args() # Just to enable --help
    
    print("--- SYSTEM CONFIGURATION ---")
    print(f"LLM Model:       {OLLAMA_MODEL}")
    print(f"Embedding Model: {EMBEDDING_MODEL}")
    print(f"DB Location:     {os.path.abspath(CHROMA_DB_PATH)}")
    print(f"Chunk Settings:  {CHUNK_SIZE} size / {CHUNK_OVERLAP} overlap")
    
    print("\n--- ACTIVE FOLDERS ---")
    active_folders = load_folders()
    if active_folders:
        for f in active_folders:
            status = "✓ Found" if os.path.exists(f) else "✗ NOT FOUND"
            print(f"  {status}: {f}")
    else:
        print("  ! No folders listed in folders.txt")
"""
config.py — Shared configuration for the local RAG pipeline.
All scripts import from here. Edit this file to change models,
paths, chunking, or retrieval settings.
"""

import os
import re
import sys

# Models
OLLAMA_MODEL    = "gemma4:latest"   # LLM used for answering
EMBEDDING_MODEL = "nomic-embed-text"   # Embedding model (can differ from OLLAMA_MODEL)

# Vector store
CHROMA_DB_PATH = "./aurelsystems" # Path to the vector store

# Chunking
CHUNK_SIZE    = 500 # Number of characters per chunk
CHUNK_OVERLAP = 50  # Number of characters to overlap between chunks

# Retrieval
TOP_K_RESULTS = 5 # Number of chunks to retrieve

# Input files
FOLDERS_FILE = "folders.txt"   # one folder path per line
PROMPT_FILE  = "prompt.txt"    # the question / prompt to ask


# Path helpers

def _win_to_wsl(path: str) -> str:
    """
    Convert a Windows-style path to a WSL path.

    Examples
    --------
    C:\\Users\\User\\docs  →  /mnt/c/Users/User/docs
    D:/Projects/reports   →  /mnt/d/Projects/reports
    /home/user/docs      →  (unchanged)
    ./relative            →  (unchanged)
    """
    path = path.strip()
    # Match   C:\...  or  C:/...
    m = re.match(r'^([A-Za-z]):[/\\](.*)$', path)
    if m:
        drive  = m.group(1).lower()
        rest   = m.group(2).replace('\\', '/')
        return f"/mnt/{drive}/{rest}"
    # Already Unix-style (absolute or relative)
    return path.replace('\\', '/')


def load_folders(filepath: str = FOLDERS_FILE) -> list[str]:
    """
    Read folder paths from *filepath*, one per line.

    • Blank lines and lines starting with '#' are ignored.
    • Windows paths (e.g. C:\\Docs) are converted to WSL paths automatically.
    • Trailing slashes are normalised.
    """
    if not os.path.exists(filepath):
        print(f"[config] ERROR: folders file not found: {filepath}", file=sys.stderr)
        sys.exit(1)

    folders = []
    with open(filepath, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            unix_path = _win_to_wsl(line)
            # Ensure trailing slash so DirectoryLoader scans the folder
            if not unix_path.endswith("/"):
                unix_path += "/"
            folders.append(unix_path)

    if not folders:
        print(f"[config] ERROR: no folders found in {filepath}", file=sys.stderr)
        sys.exit(1)

    return folders


def load_prompt(filepath: str = PROMPT_FILE) -> str:
    """Read the prompt/question from *filepath* (entire file content, stripped)."""
    if not os.path.exists(filepath):
        print(f"[config] ERROR: prompt file not found: {filepath}", file=sys.stderr)
        sys.exit(1)
    with open(filepath, encoding="utf-8") as fh:
        return fh.read().strip()

"""
config.py — Shared configuration for RAG pipeline.
This file manages models, paths, and environment-specific path conversions.
"""

import os
import re
import sys
import argparse

# --- Models ---
OLLAMA_MODEL    = "gemma4:latest"      # LLM used for answering
EMBEDDING_MODEL = "nomic-embed-text"   # Embedding model for vectorization

# --- Vector Store ---
CHROMA_DB_PATH = "./aurelsystems"      # Directory for the Chroma database

# --- Chunking & Retrieval ---
CHUNK_SIZE    = 500                    # Characters per chunk
CHUNK_OVERLAP = 50                     # Overlap between chunks
TOP_K_RESULTS = 5                      # Number of chunks to retrieve per query

# --- Input Files ---
FOLDERS_FILE = "folders.txt"           # File containing paths to scan
PROMPT_FILE  = "prompt.txt"            # File containing the main prompt/question

# --- Path Helpers ---

def _win_to_wsl(path: str) -> str:
    """
    Automatically converts Windows paths to WSL paths.
    C:\\Users\\Docs -> /mnt/c/Users/Docs
    """
    path = path.strip()
    # Match C:\... or C:/...
    m = re.match(r'^([A-Za-z]):[/\\\\](.*)', path)
    if m:
        drive, rest = m.groups()
        rest = rest.replace('\\', '/')
        return f"/mnt/{drive.lower()}/{rest}"
    # If already Unix-style or relative, just fix slashes
    return path.replace('\\', '/')

def load_folders(filepath: str = FOLDERS_FILE) -> list[str]:
    """Reads and normalizes folder paths from the folders file."""
    if not os.path.exists(filepath):
        return []
    
    folders = []
    with open(filepath, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            
            unix_path = _win_to_wsl(line)
            # Ensure the directory exists before adding
            if os.path.isdir(unix_path):
                folders.append(unix_path)
            else:
                print(f"[config] WARNING: Folder not found: {unix_path}")
                
    return folders

def load_prompt(filepath: str = PROMPT_FILE) -> str:
    """Reads the content of the prompt file."""
    if not os.path.exists(filepath):
        return "No prompt found. Please check prompt.txt."
    with open(filepath, encoding="utf-8") as fh:
        return fh.read().strip()

# --- Help & Verification ---

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Configuration & Path Verifier",
        epilog="Run this script to verify your WSL mount points and model settings."
    )
    # Parse to allow --help but we don't need actual arguments
    _ = parser.parse_known_args()

    print("="*40)
    print("CONFIGURATION CHECK")
    print("="*40)
    print(f"LLM Model:       {OLLAMA_MODEL}")
    print(f"Embedding Model: {EMBEDDING_MODEL}")
    print(f"Database Path:   {os.path.abspath(CHROMA_DB_PATH)}")
    
    print("\n--- Folder Path Verification ---")
    active_folders = load_folders()
    if not active_folders:
        print("  [!] No valid folders found. Check your folders.txt file.")
    else:
        for f in active_folders:
            print(f"  [✓] Detected: {f}")
    
    print("\n--- Prompt Preview ---")
    p_content = load_prompt()
    preview = (p_content[:75] + '...') if len(p_content) > 75 else p_content
    print(f"  Content: {preview}")
    print("="*40)
import argparse
import sys
import os
import config
from langchain_community.vectorstores import Chroma
from langchain_ollama import OllamaEmbeddings, OllamaLLM
from langchain.chains import RetrievalQA

def get_chain():
    """Helper to initialize the RAG chain."""
    if not os.path.exists(config.CHROMA_DB_PATH):
        print(f"[error] Database not found at {config.CHROMA_DB_PATH}. Run 'python database.py --rebuild' first.")
        sys.exit(1)

    embeddings = OllamaEmbeddings(model=config.EMBEDDING_MODEL)
    vectorstore = Chroma(
        persist_directory=config.CHROMA_DB_PATH,
        embedding_function=embeddings,
    )
    
    llm = OllamaLLM(model=config.OLLAMA_MODEL)
    
    return RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vectorstore.as_retriever(search_kwargs={"k": config.TOP_K_RESULTS}),
    )

def main():
    parser = argparse.ArgumentParser(
        description="RAG Query Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python query.py --file          # Run using content in prompt.txt\n"
            "  python query.py --question \"Ask your question here\"\n"
            "  python query.py --interactive   # Start a live chat session"
        )
    )
    
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--interactive", action="store_true", help="Start an interactive chat session.")
    group.add_argument("--question", type=str, metavar="STR", help="Ask a single specific question via command line.")
    group.add_argument("--file", action="store_true", help="Execute using the prompt defined in prompt.txt.")

    args = parser.parse_args()

    # Initialize the RAG logic
    qa_chain = get_chain()

    if args.file:
        prompt = config.load_prompt()
        print(f"[query] Running batch prompt from {config.PROMPT_FILE}...")
        result = qa_chain.invoke(prompt)
        print(f"\n--- ANSWER ---\n{result['result']}")

    elif args.question:
        print(f"[query] Processing question: {args.question}")
        result = qa_chain.invoke(args.question)
        print(f"\n--- ANSWER ---\n{result['result']}")

    elif args.interactive:
        print("\n--- INTERACTIVE MODE ---")
        print("Type 'exit' or 'quit' to end the session.\n")
        while True:
            user_input = input("You: ").strip()
            if user_input.lower() in ["exit", "quit"]:
                break
            if not user_input:
                continue
            
            print("Thinking...")
            result = qa_chain.invoke(user_input)
            print(f"AI: {result['result']}\n")

if __name__ == "__main__":
    main()
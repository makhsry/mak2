import argparse
import sys
import os
import config

# Modern Imports matching database.py
from langchain_community.vectorstores import Chroma
from langchain_ollama import OllamaEmbeddings, OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

def get_rag_chain():
    """Helper to initialize the RAG chain using LCEL."""
    if not os.path.exists(config.CHROMA_DB_PATH):
        print(f"[error] Database not found at {config.CHROMA_DB_PATH}. Run 'python database.py --rebuild' first.")
        sys.exit(1)

    # Setup Retrieval
    embeddings = OllamaEmbeddings(model=config.EMBEDDING_MODEL)
    vectorstore = Chroma(
        persist_directory=config.CHROMA_DB_PATH,
        embedding_function=embeddings,
    )
    retriever = vectorstore.as_retriever(search_kwargs={"k": config.TOP_K_RESULTS})

    # Setup LLM
    llm = OllamaLLM(model=config.OLLAMA_MODEL)

    # Define the Prompt Template
    template = """Answer the question based only on the following context:
    {context}

    Question: {question}
    """
    prompt = ChatPromptTemplate.from_template(template)

    # Create the Chain (LCEL style)
    chain = (
        {"context": retriever, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain

def main():
    parser = argparse.ArgumentParser(
        description="RAG Query Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python query.py --file          # Run using prompt.txt\n"
            "  python query.py --question \"...\" # Ask a specific question\n"
            "  python query.py --interactive   # Start a live chat"
        )
    )
    
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--interactive", action="store_true", help="Start an interactive chat session.")
    group.add_argument("--question", type=str, metavar="STR", help="Ask a single specific question.")
    group.add_argument("--file", action="store_true", help="Use content in prompt.txt.")

    args = parser.parse_args()
    rag_chain = get_rag_chain()

    if args.file:
        user_prompt = config.load_prompt()
        print(f"[query] Running batch prompt from {config.PROMPT_FILE}...")
        response = rag_chain.invoke(user_prompt)
        print(f"\n--- ANSWER ---\n{response}")

    elif args.question:
        print(f"[query] Processing: {args.question}")
        response = rag_chain.invoke(args.question)
        print(f"\n--- ANSWER ---\n{response}")

    elif args.interactive:
        print("\n--- INTERACTIVE MODE ---")
        print("Type 'exit' or 'quit' to end.\n")
        while True:
            user_input = input("You: ").strip()
            if user_input.lower() in ["exit", "quit"]:
                break
            if not user_input: continue
            
            print("Thinking...")
            response = rag_chain.invoke(user_input)
            print(f"AI: {response}\n")

if __name__ == "__main__":
    main()
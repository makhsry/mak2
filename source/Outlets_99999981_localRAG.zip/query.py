"""
query.py — Query the ChromaDB vector store with RAG.

Usage
-----
    python query.py

Reads the prompt from prompt.txt, retrieves relevant documents from the
vector store, and generates an answer using Ollama.
"""

import config
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import OllamaEmbeddings
#from langchain_community.llms import Ollama
from langchain_ollama import OllamaLLM
from langchain.chains import RetrievalQA

def main():
    # Load the vector store
    embeddings = OllamaEmbeddings(model=config.EMBEDDING_MODEL)
    vectorstore = Chroma(
        persist_directory=config.CHROMA_DB_PATH,
        embedding_function=embeddings,
    )

    # Load the prompt
    prompt = config.load_prompt()

    # Create the RAG chain
    #llm = Ollama(model=config.OLLAMA_MODEL)
    llm = OllamaLLM(model=config.OLLAMA_MODEL)
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vectorstore.as_retriever(search_kwargs={"k": config.TOP_K_RESULTS}),
    )

    # Run the query
    result = qa_chain.run(prompt)
    print("Answer:")
    print(result)

if __name__ == "__main__":
    main()